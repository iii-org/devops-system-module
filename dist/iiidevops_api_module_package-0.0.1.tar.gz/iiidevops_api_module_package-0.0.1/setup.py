from setuptools import setup

setup(
    name='iiidevops_api_module_package',
    version='0.0.1',
    install_requires=[
        'redis'
    ],
)