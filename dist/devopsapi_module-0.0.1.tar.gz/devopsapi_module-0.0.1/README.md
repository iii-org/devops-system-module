# package_template
A Template to build a PIP package

## Installation
Install my-project with pip
```bash
  pip install package_template
```
## Requirements
* redis==4.5.3