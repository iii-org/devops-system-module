from setuptools import setup

setup(
    name='devopsapi_module',
    version='0.0.1',
    install_requires=[
        'redis',
        'logger'
    ],
)